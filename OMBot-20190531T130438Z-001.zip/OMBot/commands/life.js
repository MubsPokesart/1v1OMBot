module.exports ={
    permissions: "none",
    help: `Tips for life.`,
    commandFunction: function (Bot, room, by, args, client) {
        Bot.say(room, `What you should get. -_-`);
    }
}